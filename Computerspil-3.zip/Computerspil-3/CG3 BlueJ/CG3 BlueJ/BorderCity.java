public class BorderCity extends City{

    /**
     * Constructor for the BorderCity class. Calls the constructor of the superclass City.
     * @param name - name of the city
     * @param value - value of the city
     * @param country - country of the city
     */
    public BorderCity(String name, int value, Country country){
        super(name, value, country);
    }

    /**
     * Overrides the arrive method from the superclass City.
     * @param p - the player that arrivs at the city
     * @return the bonus of the city minus the toll to be paid
     */
    @Override
    public int arrive(Player p) {
        int bonus = super.arrive(p);
        // Enter if player comes from another country
        if (!p.getFromCountry().equals(getCountry())) {
            int playerMoney = p.getMoney();
            //Calculate the toll ( in %)
            int tollPercent = getCountry().getGame().getSettings().getTollToBePaid();
            int toll = (playerMoney * tollPercent) /100;
            changeValue(toll);
            return bonus - toll;
        }
        return bonus;
    }
}
