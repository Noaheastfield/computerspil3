import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class MafiaCountryTest {

    private Game game;
    private Country country1, country2;
    private City cityA, cityB, cityC, cityD, cityE, cityF, cityG;

    @BeforeEach
    public void setUp()
    {
        game = new Game();
        // Create countries
        country1 = new Country("Country 1");
        country2 = new Country("Country 2");

        // Create cities
        cityA = new City("City A", 80, country1);
        cityB = new City("City B", 60, country1);
        cityC = new CapitalCity("City C", 40, country1);
        cityD = new City("City D", 100, country1);
        cityE = new City("City E", 50, country2);
        cityF = new City("City F", 90, country2);
        cityG = new City("City G", 70, country2);

        // Connect cities to countries
        country1.addCity(cityA);
        country1.addCity(cityB);
        country1.addCity(cityC);
        country1.addCity(cityD);

        country2.addCity(cityE);
        country2.addCity(cityF);
        country2.addCity(cityG);

        // Create roads
        country1.addRoads(cityA, cityB, 4);
        country1.addRoads(cityA, cityC, 3);
        country1.addRoads(cityA, cityD, 5);
        country1.addRoads(cityB, cityD, 2);
        country1.addRoads(cityC, cityD, 2);
        country1.addRoads(cityC, cityE, 4);
        country1.addRoads(cityD, cityF, 3);
        country2.addRoads(cityE, cityC, 4);
        country2.addRoads(cityE, cityF, 2);
        country2.addRoads(cityE, cityG, 5);
        country2.addRoads(cityF, cityD, 3);
        country2.addRoads(cityF, cityG, 6);

        game.addCountry(country1);
        game.addCountry(country2);
    }
    @Test
    public void bonusNoRobbery() {
        game.getSettings().setRisk(0);

        for (int seed = 0; seed++ < 100;) {
            game.getRandom().setSeed(seed);

            int sum = 0;
            Set<Integer> set = new HashSet<>();
            for (int i = 0; i++ < 100_000;) {
                int bonus = country1.bonus(80);
                sum += bonus;
                set.add(bonus);

                assertTrue(0 <= bonus && bonus <= 80);
            }

            int expectedSum = 100_000 * (80+1)/2;
            assertTrue(expectedSum * 0.98 <= sum && sum <= expectedSum * 1.02);
            assertEquals(81, set.size());
        }

        assertEquals(0, country1.bonus(0));
        int bonus = country1.bonus(1);
        assertTrue(bonus == 1 || bonus == 0);

    }

    @Test
    public void bonusWithRobbery() {
        game.getSettings().setRisk(20);

        for (int seed = 0; seed++ < 100;) {
            game.getRandom().setSeed(seed);

            int sumOfLoss = 0;
            int numOfRobbery = 0;
            Set<Integer> set = new HashSet<>();
            for (int i = 0; i++ < 100_000; ) {
                int bonus = country1.bonus(80);
                if (bonus >= 0) continue;


                numOfRobbery++;

                sumOfLoss += Math.abs(bonus);
                set.add(bonus);
                assertTrue(-50 <= bonus && bonus <= -10);

            }

            int expectedNumOfRobbery = 100_000 / 5;
            int expectedSumOfLoss = numOfRobbery * 30;

            // Check the change for robbery
            assertTrue(expectedNumOfRobbery * 0.98 <= numOfRobbery && numOfRobbery <= expectedNumOfRobbery * 1.02);

            // Check the expected sum of loss, when robbed
            assertTrue(expectedSumOfLoss * 0.98 <= sumOfLoss && sumOfLoss <= expectedSumOfLoss * 1.02);

            assertEquals(41, set.size());
        }

        assertTrue(0 >= country1.bonus(0));
        assertTrue(1 >= country1.bonus(1));

    }
}
