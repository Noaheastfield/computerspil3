import java.util.Random;

public class MafiaCountry extends Country{
    /**
     * Constructor for the Country class.
     * @param name - the name of the country
     */
    public MafiaCountry(String name) {
        super(name);
    }

    @Override
    public int bonus(int value){
        int mafiaPercent = getGame().getSettings().getRisk();
        Random rand = new Random();
        int robOrNoRob = rand.nextInt(100);

        if(mafiaPercent < robOrNoRob){
            int mafiaLoss = getGame().getLoss();
            return -mafiaLoss;
        }
        return super.bonus(value);

    }
}
