import java.io.IOException;
import java.net.URISyntaxException;

public class Main {
    public static void main(String[] args) throws IOException, URISyntaxException {
        TestServer.testAndOpenInBrowser("CG3-1");
    }
}
