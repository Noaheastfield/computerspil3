import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
public class CapitalCityTest {
        private Game game;
        private Country country1, country2;
        private City cityA, cityB, cityC, cityD, cityE, cityF, cityG;

        @BeforeEach
        public void setUp()
        {
            game = new Game();
            // Create countries
            country1 = new Country("Country 1");
            country2 = new Country("Country 2");

            // Create cities
            cityA = new City("City A", 80, country1);
            cityB = new City("City B", 60, country1);
            cityC = new CapitalCity("City C", 40, country1);
            cityD = new City("City D", 100, country1);
            cityE = new City("City E", 50, country2);
            cityF = new City("City F", 90, country2);
            cityG = new City("City G", 70, country2);

            // Connect cities to countries
            country1.addCity(cityA);
            country1.addCity(cityB);
            country1.addCity(cityC);
            country1.addCity(cityD);

            country2.addCity(cityE);
            country2.addCity(cityF);
            country2.addCity(cityG);

            // Create roads
            country1.addRoads(cityA, cityB, 4);
            country1.addRoads(cityA, cityC, 3);
            country1.addRoads(cityA, cityD, 5);
            country1.addRoads(cityB, cityD, 2);
            country1.addRoads(cityC, cityD, 2);
            country1.addRoads(cityC, cityE, 4);
            country1.addRoads(cityD, cityF, 3);
            country2.addRoads(cityE, cityC, 4);
            country2.addRoads(cityE, cityF, 2);
            country2.addRoads(cityE, cityG, 5);
            country2.addRoads(cityF, cityD, 3);
            country2.addRoads(cityF, cityG, 6);

            game.addCountry(country1);
            game.addCountry(country2);
        }

        @Test
        public void arriveFromOtherCountry() {
            //test 1000 different times
            for(int seed = 0; seed < 1000; seed++) {
                //Set the position of our player on a road
                Player player = new GUIPlayer(new Position(cityE, cityC, 0), 250);
                game.getRandom().setSeed(seed);
                // Calculate the bonus, toll, and goodie
                int bonus = country1.bonus(cityC.getValue());
                int toll = (250 / 5);
                int goodies = game.getRandom().nextInt(player.getMoney() + bonus -toll +1);
                game.getRandom().setSeed(seed);
                //Test if arrive() method is overwritten correctedly when the player comes from another country
                assertEquals(bonus - toll - goodies, cityC.arrive(player));
                //Test if the value is changed correctly according to our arrive() methode (Different countries)
                assertEquals(cityC.getInitialValue() - bonus + toll + goodies, cityC.getValue());
                cityC.reset();
            }
        }

        @Test
        public void arriveFromSameCountry() {
            //test 1000 different times
            for(int seed = 0; seed < 1000; seed++) {
                Player player = new GUIPlayer(new Position(cityA, cityC, 0), 250);
                game.getRandom().setSeed(seed);
                // Calculate the bonus, and goodie
                int bonus = country1.bonus(cityC.getValue());
                int goodies = game.getRandom().nextInt(player.getMoney() + bonus +1);
                game.getRandom().setSeed(seed);
                //Test if arrive() method is overwritten correctedly when the player comes from the same country
                assertEquals(bonus - goodies, cityC.arrive(player));
                //Test if the value is changed correctly according to our arrive() methode (Same country)
                assertEquals(cityC.getInitialValue() - bonus + goodies, cityC.getValue());
                cityC.reset();
            }
        }
    }
